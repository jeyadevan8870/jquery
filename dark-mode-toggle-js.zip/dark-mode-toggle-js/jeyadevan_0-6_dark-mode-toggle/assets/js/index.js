const inputEl = document.querySelector(".input");
const bodyEl = document.querySelector("body");
const h1El = document.querySelector("h1");

inputEl.checked = JSON.parse(localStorage.getItem("mode")) || false;

updateBody();

function updateBody() {
  if (inputEl.checked) {
    bodyEl.classList.remove('light-mode');
    bodyEl.classList.add('dark-mode');
    h1El.classList.remove('light-mode');
    h1El.classList.add('dark-mode');
  } else {
    bodyEl.classList.remove('dark-mode');
    bodyEl.classList.add('light-mode');
    h1El.classList.remove('dark-mode');
    h1El.classList.add('light-mode');
  }
}

inputEl.addEventListener("input", () => {
  updateBody();
  updateLocalStorage();
});

function updateLocalStorage() {
  localStorage.setItem("mode", JSON.stringify(inputEl.checked));
}

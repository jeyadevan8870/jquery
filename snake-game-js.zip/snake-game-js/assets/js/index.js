const gameBoard = document.getElementById('gameBoard');
const context = gameBoard.getContext('2d');
const scoreText = document.getElementById('scoreVal');
const startButton = document.getElementById('startButton');
const pauseButton = document.getElementById('pauseButton');

const WIDTH = gameBoard.width;
const HEIGHT = gameBoard.height;
const UNIT = 25;

let foodX;
let foodY;
let xVel = UNIT;
let yVel = 0;
let score = 0;
let active = true;
let started = false;
let paused = false;

let snake = [
    { x: UNIT * 3, y: 0 },
    { x: UNIT * 2, y: 0 },
    { x: UNIT, y: 0 },
    { x: 0, y: 0 }
];

window.addEventListener('keydown', keyPress);
startButton.addEventListener('click', startGame);
pauseButton.addEventListener('click', togglePause);

function startGame() {
    if (!started) {
        started = true;
        active = true;
        paused = false;
        score = 0;
        scoreText.textContent = score;
        xVel = UNIT;
        yVel = 0;
        snake = [
            { x: UNIT * 3, y: 0 },
            { x: UNIT * 2, y: 0 },
            { x: UNIT, y: 0 },
            { x: 0, y: 0 }
        ];
        createFood();
        nextTick();
    }
}

function clearBoard() {
    context.fillStyle = '#212121';
    context.fillRect(0, 0, WIDTH, HEIGHT);
}

function createFood() {
    foodX = Math.floor(Math.random() * WIDTH / UNIT) * UNIT;
    foodY = Math.floor(Math.random() * HEIGHT / UNIT) * UNIT;
}

function displayFood() {
    const gradient = context.createRadialGradient(foodX + UNIT / 2, foodY + UNIT / 2, UNIT / 4, foodX + UNIT / 2, foodY + UNIT / 2, UNIT / 2);
    gradient.addColorStop(0, 'yellow');
    gradient.addColorStop(1, 'red');
    context.fillStyle = gradient;
    context.fillRect(foodX, foodY, UNIT, UNIT);
}

function drawSnake() {
    snake.forEach((snakePart, index) => {
        const gradient = context.createLinearGradient(snakePart.x, snakePart.y, snakePart.x + UNIT, snakePart.y + UNIT);
        gradient.addColorStop(0, 'lightgreen');
        gradient.addColorStop(1, 'darkgreen');
        context.fillStyle = gradient;
        context.fillRect(snakePart.x, snakePart.y, UNIT, UNIT);
        context.strokeStyle = '#212121';
        context.strokeRect(snakePart.x, snakePart.y, UNIT, UNIT);
    });
}

function moveSnake() {
    const head = { x: snake[0].x + xVel, y: snake[0].y + yVel };
    snake.unshift(head);
    if (snake[0].x == foodX && snake[0].y == foodY) {
        score += 1;
        scoreText.textContent = score;
        createFood();
    } else {
        snake.pop();
    }
}

function nextTick() {
    if (active && !paused) {
        setTimeout(() => {
            clearBoard();
            displayFood();
            moveSnake();
            drawSnake();
            checkGameOver();
            nextTick();
        }, 200);
    } else if (!active) {
        clearBoard();
        context.font = "bold 50px serif";
        context.fillStyle = "white";
        context.textAlign = "center";
        context.fillText("Game Over!!", WIDTH / 2, HEIGHT / 2);
        displayRetryButton();
        started = false;
    }
}

function togglePause() {
    if (started) {
        paused = !paused;
        pauseButton.textContent = paused ? "Resume" : "Pause";
        if (!paused) nextTick();
    }
}

function keyPress(event) {
    const LEFT = 37;
    const UP = 38;
    const RIGHT = 39;
    const DOWN = 40;

    switch (true) {
        case (event.keyCode == LEFT && xVel != UNIT):
            xVel = -UNIT;
            yVel = 0;
            break;
        case (event.keyCode == RIGHT && xVel != -UNIT):
            xVel = UNIT;
            yVel = 0;
            break;
        case (event.keyCode == UP && yVel != UNIT):
            xVel = 0;
            yVel = -UNIT;
            break;
        case (event.keyCode == DOWN && yVel != -UNIT):
            xVel = 0;
            yVel = UNIT;
            break;
    }
}

function checkGameOver() {
    switch (true) {
        case (snake[0].x < 0):
        case (snake[0].x >= WIDTH):
        case (snake[0].y < 0):
        case (snake[0].y >= HEIGHT):
            active = false;
            break;
    }

    for (let i = 1; i < snake.length; i++) {
        if (snake[i].x === snake[0].x && snake[i].y === snake[0].y) {
            active = false;
        }
    }
}

function displayRetryButton() {
    const retryButton = document.createElement('button');
    retryButton.textContent = "Retry";
    retryButton.style.padding = "10px 20px";
    retryButton.style.fontSize = "16px";
    retryButton.style.color = "#fff";
    retryButton.style.backgroundColor = "#00796b";
    retryButton.style.border = "none";
    retryButton.style.borderRadius = "5px";
    retryButton.style.cursor = "pointer";
    retryButton.style.transition = "background-color 0.3s ease, transform 0.2s ease";
    retryButton.style.marginTop = "20px";

    retryButton.addEventListener('click', () => {
        retryButton.remove();
        clearBoard();
        startGame();
    });

    document.body.appendChild(retryButton);
}

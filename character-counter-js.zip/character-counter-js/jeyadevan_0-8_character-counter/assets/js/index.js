const textareaElement = document.querySelector(".textarea");
const total = document.querySelector(".total");
const remain = document.querySelector(".remain");

textareaElement.addEventListener("keyup", () => {
  updateCounter();
});

updateCounter();

function updateCounter() {
  total.innerText = textareaElement.value.length;
  remain.innerText = textareaElement.getAttribute("maxLength") - textareaElement.value.length;
  
  total.classList.add('update-animation');
  remain.classList.add('update-animation');

  setTimeout(() => {
    total.classList.remove('update-animation');
    remain.classList.remove('update-animation');
  }, 300);
}
